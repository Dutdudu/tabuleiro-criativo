using UnityEngine;

public class ColorPicker : MonoBehaviour
{
    public SquarePainter squarePainter;

    // Este método pode ser chamado quando o usuário escolhe uma cor e um quadrado
    public void OnColorPicked(int squareIndex, Color pickedColor)
    {
        squarePainter.PaintSquare(squareIndex, pickedColor);
    }
}
