using UnityEngine;
using UnityEngine.UI;

public class ColorPickerUI : MonoBehaviour
{
    public ColorPicker colorPicker;
    public InputField indexInputField; // Campo de input para o índice do quadrado
    public Button selectColorButton; // Botão para confirmar a seleção de cor
    public Button[] colorButtons; // Botões de cor

    private Color selectedColor;

    void Start()
    {
        // Adiciona listeners aos botões de cor
        foreach (Button button in colorButtons)
        {
            button.onClick.AddListener(() => OnColorButtonClick(button));
        }

        // Adiciona listener ao botão de seleção de cor
        selectColorButton.onClick.AddListener(OnSelectColorButtonClick);
    }

    // Método chamado quando um botão de cor é clicado
    void OnColorButtonClick(Button button)
    {
        selectedColor = button.GetComponent<Image>().color;
    }

    // Método chamado quando o botão de seleção de cor é clicado
    void OnSelectColorButtonClick()
    {
        if (int.TryParse(indexInputField.text, out int squareIndex))
        {
            colorPicker.OnColorPicked(squareIndex, selectedColor);
        }
    }
}
