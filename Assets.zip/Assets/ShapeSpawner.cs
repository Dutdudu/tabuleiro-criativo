using UnityEngine;

public class ShapeSpawner : MonoBehaviour
{
    // Prefabs das formas que serão instanciadas
    public GameObject circlePrefab;
    public GameObject squarePrefab;
    public GameObject trianglePrefab;
    public GameObject starPrefab;
    public GameObject pentagonPrefab;
    public GameObject hexagonPrefab;

    void Start()
    {
        // Carrega as quantidades salvas usando PlayerPrefs
        int circleCount = PlayerPrefs.GetInt("CircleCount", 0);
        int squareCount = PlayerPrefs.GetInt("SquareCount", 0);
        int triangleCount = PlayerPrefs.GetInt("TriangleCount", 0);
        int starCount = PlayerPrefs.GetInt("StarCount", 0);
        int pentagonCount = PlayerPrefs.GetInt("PentagonCount", 0);
        int hexagonCount = PlayerPrefs.GetInt("HexagonCount", 0);

        // Chama o método para instanciar as formas conforme as quantidades carregadas
        SpawnShapes(circleCount, circlePrefab);
        SpawnShapes(squareCount, squarePrefab);
        SpawnShapes(triangleCount, trianglePrefab);
        SpawnShapes(starCount, starPrefab);
        SpawnShapes(pentagonCount, pentagonPrefab);
        SpawnShapes(hexagonCount, hexagonPrefab);
    }

    // Método para instanciar a quantidade de formas desejadas
    void SpawnShapes(int count, GameObject prefab)
    {
        for (int i = 0; i < count; i++)
        {
            // Instancia as formas em posições aleatórias na cena
            Instantiate(prefab, new Vector3(Random.Range(-8, 0), Random.Range(-2, 2), 0), Quaternion.identity);
        }
    }
}
