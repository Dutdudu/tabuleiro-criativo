using UnityEngine;

public class SquarePainter : MonoBehaviour
{
    public void PaintSquare(int squareIndex, Color color)
    {
        SquareState squareState = GameManager.Instance.squareState;
        if (squareState != null && squareState.squareColors.Length > squareIndex)
        {
            squareState.squareColors[squareIndex] = color;
        }
    }
}
