using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class ShapeManager : MonoBehaviour
{
    public int circleCount = 0;
    public int squareCount = 0;
    public int triangleCount = 0;
    public int starCount = 0;
    public int pentagonCount = 0;
    public int hexagonCount = 0;

    public Text circleText;
    public Text squareText;
    public Text triangleText;
    public Text starText;
    public Text pentagonText;
    public Text hexagonText;

    void Start()
    {
        UpdateUI();
    }

    public void IncreaseCircle()
    {
        circleCount++;
        UpdateUI();
    }

    public void IncreaseSquare()
    {
        squareCount++;
        UpdateUI();
    }

    public void IncreaseTriangle()
    {
        triangleCount++;
        UpdateUI();
    }

    public void IncreaseStar()
    {
        starCount++;
        UpdateUI();
    }

    public void IncreasePentagon()
    {
        pentagonCount++;
        UpdateUI();
    }

    public void IncreaseHexagon()
    {
        hexagonCount++;
        UpdateUI();
    }

    void UpdateUI()
    {
        circleText.text = "Circle: " + circleCount;
        squareText.text = "Square: " + squareCount;
        triangleText.text = "Triangle: " + triangleCount;
        starText.text = "Star: " + starCount;
        pentagonText.text = "Pentagon: " + pentagonCount;
        hexagonText.text = "Hexagon: " + hexagonCount;
    }
    public void SaveQuantities()
{
    PlayerPrefs.SetInt("CircleCount", circleCount);
    PlayerPrefs.SetInt("SquareCount", squareCount);
    PlayerPrefs.SetInt("TriangleCount", triangleCount);
    PlayerPrefs.SetInt("StarCount", starCount);
    PlayerPrefs.SetInt("PentagonCount", pentagonCount);
    PlayerPrefs.SetInt("HexagonCount", hexagonCount);

    PlayerPrefs.Save(); // Salva as mudanças nos PlayerPrefs
}
// Método para salvar os dados e carregar a próxima cena
    public void SaveDataAndChangeScene()
    {
        SaveQuantities(); // Salva as quantidades selecionadas
        //SceneManager.LoadScene("NextScene"); // Substitua "NextScene" pelo nome da próxima cena
    }

}
